# IG-Template-REST
Implementation guide template for REST based messaging.
